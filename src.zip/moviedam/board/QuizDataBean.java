package moviedam.board;

public class QuizDataBean {
	private String episode;
	private String mem_userid;
	private String radio1;
	private String radio2;
	private String radio3;
	public String getEpisode() {
		return episode;
	}

	public void setEpisode(String episode) {
		this.episode = episode;
	}

	public String getMem_userid() {
		return mem_userid;
	}

	public void setMem_userid(String mem_userid) {
		this.mem_userid = mem_userid;
	}

		public String getRadio1() {
		return radio1;
	}

	public void setRadio1(String radio1) {
		this.radio1 = radio1;
	}

	public String getRadio2() {
		return radio2;
	}

	public void setRadio2(String radio2) {
		this.radio2 = radio2;
	}

	public String getRadio3() {
		return radio3;
	}

	public void setRadio3(String radio3) {
		this.radio3 = radio3;
	}
}
