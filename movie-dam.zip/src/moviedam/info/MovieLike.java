package moviedam.info;

public class MovieLike {
	private int movie_like_id;
	private String movieCd;
	private int mem_id;
	
	public int getMovie_like_id() {
		return movie_like_id;
	}
	public void setMovie_like_id(int movie_like_id) {
		this.movie_like_id = movie_like_id;
	}
	public String getMovieCd() {
		return movieCd;
	}
	public void setMovieCd(String movieCd) {
		this.movieCd = movieCd;
	}
	public int getMem_id() {
		return mem_id;
	}
	public void setMem_id(int mem_id) {
		this.mem_id = mem_id;
	}
	
}
